// Authentication middleware

function requireLogin(req, res, next) {
  if (!req.session.user) {
    req.session.returnTo = req.originalUrl;
    return res.redirect('/login');
  }
  // Check if user is banned
  const db = req.app.locals.db;
  const user = db.prepare('SELECT role FROM users WHERE id = ?').get(req.session.user.id);
  if (user && user.role === 'banned') {
    req.session.destroy();
    return res.redirect('/login?error=banned');
  }
  next();
}

function requireAdmin(req, res, next) {
  if (!req.session.user || req.session.user.role !== 'admin') {
    return res.status(403).render('error', { title: 'Access Denied', message: 'You do not have permission to access this page.' });
  }
  next();
}

function isShadowBanned(req) {
  if (!req.session.user) return false;
  const db = req.app.locals.db;
  const user = db.prepare('SELECT role FROM users WHERE id = ?').get(req.session.user.id);
  return user && user.role === 'shadowbanned';
}

module.exports = { requireLogin, requireAdmin, isShadowBanned };
